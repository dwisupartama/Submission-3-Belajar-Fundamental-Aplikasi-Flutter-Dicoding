enum ResultState { loading, noData, hasData, error }
enum ResultStateReview { loading, noData, hasData, error, noAddReview }
enum ResultStateSearch { loading, noData, hasData, error, noKey }
