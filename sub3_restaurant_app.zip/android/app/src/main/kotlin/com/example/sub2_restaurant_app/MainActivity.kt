package com.example.sub2_restaurant_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
